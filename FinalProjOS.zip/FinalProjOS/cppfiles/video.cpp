void play_video() {
    char filename[100];
    printf("\n🎬 Enter the name of the video file (e.g., video.mp4): ");
    scanf("%s", filename);
    char cmd[256];
    snprintf(cmd, sizeof(cmd), "mpv /home/ns3/Videos/%s", filename);
    system(cmd);
}

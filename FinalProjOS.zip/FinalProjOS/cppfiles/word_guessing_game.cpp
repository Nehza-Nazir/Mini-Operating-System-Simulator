void guess_game() {
    char p1name[50], p2name[50];
    printf("\n🎮 Welcome to the Word Guessing Game!\n");
    printf("Enter Player 1 name: ");
    scanf("%s", p1name);
    printf("Enter Player 2 name: ");
    scanf("%s", p2name);

    const char *words[] = {"intelligent", "osproject", "amama", "nehza", "coding", "terminal", "linux", "compile", "function", "computer"};
    int guessed[10] = {0};
    int p1 = 0, p2 = 0, turn = 0, round = 0;
    srand(time(NULL));

    while (p1 < 4 && p2 < 4 && round < 10) {
        int idx;
        do { idx = rand() % 10; } while (guessed[idx]);
        guessed[idx] = 1;
        const char *word = words[idx];
        int len = strlen(word);
        printf("\n%s's turn!\n", turn == 0 ? p1name : p2name);
        if (rand() % 2 == 0) {
            printf("Guess the word that starts with '%.*s': ", len/2, word);
        } else {
            printf("Guess the word that ends with '%.*s': ", len - len/2, word + len/2);
        }
        char guess[100];
        scanf("%s", guess);
        if (strcmp(guess, word) == 0) {
            printf("Correct!\n");
            if (turn == 0) p1++; else p2++;
        } else {
            printf("Incorrect. The correct word was: %s\n", word);
        }
        printf("%s score: %d | %s score: %d\n", p1name, p1, p2name, p2);
        turn = 1 - turn;
        round++;
    }
    if (p1 >= 4) printf("%s wins!\n", p1name);
    else if (p2 >= 4) printf("%s wins!\n", p2name);
    else printf("Game over! No winner.\n");
}


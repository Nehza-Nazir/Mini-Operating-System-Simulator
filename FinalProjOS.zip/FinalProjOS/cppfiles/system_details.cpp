void system_details() {
    printf("\n🖥️ System Information:\n");
    system("uname -a");
}

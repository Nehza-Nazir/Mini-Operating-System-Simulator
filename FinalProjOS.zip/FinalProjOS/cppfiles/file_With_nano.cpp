void open_with_nano() {
    char filename[100];
    printf("\n📝 Enter file name to open with nano: ");
    scanf("%s", filename);
    char cmd[150];
    snprintf(cmd, sizeof(cmd), "nano %s", filename);
    system(cmd);
}

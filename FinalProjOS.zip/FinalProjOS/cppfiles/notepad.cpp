void notepad() {
 system("nano");
}
